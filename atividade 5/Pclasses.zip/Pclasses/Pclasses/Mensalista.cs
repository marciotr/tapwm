﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pclasses
{
    internal class Mensalista : Empregado
    {
        public double SalarioMensal { get; set; }

        public static string Empresa = "Tesla";
        public const string Filial = "Filial Brasil";

        public Mensalista(int matx, string nomex, DateTime datax, double salx)
        {
            this.NomeEmpregado = nomex;
            this.Matricula = matx;
            this.DataEntradaEmpresa = datax;
            this.SalarioMensal = salx;
        }

        public Mensalista()
        {
            System.Windows.Forms.MessageBox.Show("Aqui é mensalista");
        }

        public override double SalarioBruto()
        {
            return SalarioMensal;
        }
    }
}
