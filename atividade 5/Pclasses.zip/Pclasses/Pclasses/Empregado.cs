﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pclasses
{
    internal abstract class Empregado
    {
        public const string nome = "Zé";
        public static string nome1 = "ZéStatico";

        private int matricula;
        private string nomeEmpregado;
        private DateTime dataEntradaEmpresa;

        public Empregado()
        {
            System.Windows.Forms.MessageBox.Show("Aqui é empregado!");
        }

        public Empregado(int mat, string nome, DateTime datax)
        {
            matricula = mat;
            nomeEmpregado = nome;
            dataEntradaEmpresa = datax;
        }

        public int Matricula
        {
            get { return matricula;}
            set { matricula = value;}
        }

        public string NomeEmpregado
        {
            get { return nomeEmpregado;}
            set { nomeEmpregado = value;}
        }
        //private List<Dependente> depentendes = new List<Dependente>;

        public DateTime DataEntradaEmpresa
        {
            get { return dataEntradaEmpresa;}
            set { dataEntradaEmpresa = value;}
        }

        public virtual int TempoTrabalho()
        {
            TimeSpan span = DateTime.Today.Subtract(DataEntradaEmpresa);

            return (span.Days);
        }
        public abstract double SalarioBruto();
    }
}
